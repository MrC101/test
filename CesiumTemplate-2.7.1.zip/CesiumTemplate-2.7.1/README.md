# CESIUM TEMPLATE

### [INSTALLATION]
- Upload all the contents of "upload" directory to the root directory of your NamelessMC installation.
- Then login to your staff panel, and head over to templates section and click "Install" button.
- Then enable the newly appeared template named "Cesium", also make it default.
- Thats it!

### [CUSTOMIZATION]
- The template can be customized from template settings page.
- Login to your staff panel, and head over to templates section.
- Then click settings button in the Cesium template row.
- There you can customize the template.

### [CHANGING PRIMARY COLOR]
- Head over to template settings page.
- Select "Themes" from sidebar, and click edit button of the active theme.
- Click "Colors" from top navigation and change the primary color.
- That's it!

### [THEMES IMPORT]
- Head over to template settings page.
- Select "Themes" from sidebar, and click import button on top right side.
- A modal will popup, browse the theme json file and click the "Submit" button.
- When it's done, it will automatically appear on themes page.

(There are 3 themes inside "themes" directory you can import)

### [AGREEMENT]
- You will not re-sell.
- You will not re-distribute.
- You will not claim this as your own.
- You will not steal the code.
- You will only use it on your own site.
- You will not use it for illegal purposes or use it on illegal websites.
- You may modify.
- You may sell custom themes (only the theme JSON file).
- You will not chargeback.

### [CONTACT]
- Discord: https://xemah.com/support
- Email: contact@xemah.com
