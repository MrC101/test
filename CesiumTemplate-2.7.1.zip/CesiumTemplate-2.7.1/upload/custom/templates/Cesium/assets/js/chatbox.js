/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

var chatbox = {

	template: `
		<div class="card card-chatbox" id="chatbox">
			<div class="card-header">
				{chatboxTitle}
			</div>
			<div class="card-body">
				<div class="list chat-list" id="chatLog">
					{chatboxLoading}
				</div>
			</div>
			<div class="card-footer">
				<form action="" class="disabled" id="chatForm" autocomplete="off">
					<div class="input-group">
						<input type="text" class="form-control" id="chatInput" placeholder="{chatboxMessagePlaceholder}" />
						<div class="input-group-append">
							<button type="submit" class="btn btn-primary" id="chatInputSubmit">
								<i class="fas fa-share fa-fw"></i>
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	`,

	itemTemplate: `
		<div class="list-item" id="chatMessage-{messageId}">
			<a href="{authorProfile}" class="list-icon">
				<img src="{authorAvatar}">
			</a>
			<div class="list-content">
				<div class="meta">
					<a class="author" href="{authorProfile}" style="{authorStyle}">{authorUsername}</a>
					<small title="{messageTimeFull}">{messageTime}</small>
				</div>
				{messageContent}
			</div>
			<div class="list-actions">
				{messageActions}
			</div>
		</div>
	`,
	
	elements: {
		containerTop: '#chatbox-top',
		containerBottom: '#chatbox-bottom',
		root: '#chatbox',
		log: '#chatbox #chatLog',
		form: '#chatbox #chatForm',
		input: '#chatbox #chatInput'
	},

	style: ``

}