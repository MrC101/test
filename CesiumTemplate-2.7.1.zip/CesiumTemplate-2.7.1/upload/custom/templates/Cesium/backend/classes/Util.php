<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

class CSM_Util {

	/**
	 *	@var string $_templatePath The path to the template
	 */

	private $_templatePath = '/custom/templates/Cesium';

	/**
	 *	buildPanelURL()
	 *	Builds the panel url linked with the module
	 *	
	 *	@param string $url The url to build
	 *	@param string $params The parameters of the url (optional)
	 *	@return string Formatted URL
	 */

	public function buildPanelURL($url, $params = '') {

		if (strpos($url, '/') === 0) {
			$url = '&page=' . ltrim($url, '/');
		}

		if ($params !== '') {
			$url = $url . '&' . $params;
		}

		$queries = new Queries;
		$templateQuery = $queries->getWhere('templates', array('name', '=', 'Cesium'));

		return URL::build('/panel/core/templates/', 'action=settings&template=' . $templateQuery[0]->id . $url);
		
	}

	/**
	 *	buildPath()
	 *	Builds the path to the template backend
	 *	
	 *	@param string $path
	 *	@return string Formatted Path
	 */

	public function buildPath($path) {

		$path = ROOT_PATH . $this->_templatePath . '/backend' . $path;
		return $path;

	}

	/**
	 *	buildTemplatePath()
	 *	Builds the path to the template
	 *	
	 *	@param string $path
	 *	@return string Formatted Path
	 */

	public function buildTemplatePath($path) {

		$path = ROOT_PATH . $this->_templatePath . $path;
		return $path;

	}

	/**
	 *	minifyCSS()
	 *	Minify the CSS
	 *	
	 *	@param string $css
	 *	@return string Compressed CSS Content
	 *	@author Steffen Becker
	 *	@link https://gist.github.com/webgefrickel/3339063
	 */

	public function minifyCSS($css) {

		// Remove comments
		$css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);

		// Backup values within single or double quotes
		preg_match_all('/(\'[^\']*?\'|"[^"]*?")/ims', $css, $hit, PREG_PATTERN_ORDER);
		for ($i=0; $i < count($hit[1]); $i++) {
		  $css = str_replace($hit[1][$i], '##########' . $i . '##########', $css);
		}

		// Remove traling semicolon of selector's last property
		$css = preg_replace('/;[\s\r\n\t]*?}[\s\r\n\t]*/ims', "}\r\n", $css);

		// Remove any whitespace between semicolon and property-name
		$css = preg_replace('/;[\s\r\n\t]*?([\r\n]?[^\s\r\n\t])/ims', ';$1', $css);

		// Remove any whitespace surrounding property-colon
		$css = preg_replace('/[\s\r\n\t]*:[\s\r\n\t]*?([^\s\r\n\t])/ims', ':$1', $css);

		// Remove any whitespace surrounding selector-comma
		$css = preg_replace('/[\s\r\n\t]*,[\s\r\n\t]*?([^\s\r\n\t])/ims', ',$1', $css);

		// Remove any whitespace surrounding opening parenthesis
		$css = preg_replace('/[\s\r\n\t]*{[\s\r\n\t]*?([^\s\r\n\t])/ims', '{$1', $css);

		// Remove any whitespace between numbers and units
		$css = preg_replace('/([\d\.]+)[\s\r\n\t]+(px|em|pt|%)/ims', '$1$2', $css);

		// Shorten zero-values
		$css = preg_replace('/([^\d\.]0)(px|em|pt|%)/ims', '$1', $css);

		// Constrain multiple whitespaces
		$css = preg_replace('/\p{Zs}+/ims',' ', $css);

		// Remove newlines
		$css = str_replace(array("\r\n", "\r", "\n"), '', $css);

		// Restore backupped values within single or double quotes
		for ($i=0; $i < count($hit[1]); $i++) {
		  $css = str_replace('##########' . $i . '##########', $hit[1][$i], $css);
		}

		return $css;

	}

	/**
	 *	sanitizeString()
	 *	Sanitizes a string for filename
	 *	
	 *	@param string $string
	 *	@return string Sanitized filename
	 *	@author Xemah
	 */

	public function sanitizeString($str) {

		$string = strtolower($str);
		$string = str_replace(' ', '_', $string);
		$string = preg_replace('/[^a-z0-9\_]/', '', $string);
		return $string;

	}

}