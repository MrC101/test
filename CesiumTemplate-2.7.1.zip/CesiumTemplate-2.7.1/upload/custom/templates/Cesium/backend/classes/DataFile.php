<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

class CSM_DataFile {
	
	/**
	 *	@var string $_storagePath The path where to look the files
	 */

	private $_storagePath = '/custom/templates/Cesium/backend/storage/';

	/**
	 *	@var string $_file The path to the file when loaded
	 */
	
	private $_file;

	/**
	 *	checkExistence()
	 *	Checks if a file exists (If not, throws an error)
	 *	
	 *	@param string $filePath The path of the file
	 *	@throws Exception If the file is not find
	 *	@return void
	 */

	public function checkExistence($filePath) {

		if (!file_exists($filePath)) {
			throw new Exception('The file \'' . $filePath . '\' does not exists.');
		}

	}

	/**
	 *	checkReadability()
	 *	Checks if a file is readable (If not, throws an error)
	 *	
	 *	@throws Exception If the file is not readable
	 *	@return void
	 */

	public function checkReadability() {

		if (!$this->_file) {
			throw New Exception('No file is loaded.');
		}

		$this->checkExistence($this->_file);

		if (!is_readable($this->_file)) {
			throw new Exception('The file \'' . $this->_file . '\' is not readable.');
		}

	}

	/**
	 *	checkWritability()
	 *	Checks if a file is writeable (If not, throws an error)
	 *	
	 *	@throws Exception If the file is not writeable
	 *	@return void
	 */

	public function checkWritability() {

		if (!$this->_file) {
			throw New Exception('No file is loaded.');
		}

		$this->checkExistence($this->_file);

		if (!is_writable($this->_file)) {
			throw new Exception('The file \'' . $this->_file . '\' is not writeable.');
		}

	}

	/**
	 *	load()
	 *	Loads the file in the memory
	 *	
	 *	@param string $fileName The name of the file
	 *	@return void
	 */
	
	public function load($fileName) {

		try {

			$filePath = ROOT_PATH . $this->_storagePath . $fileName . '.json';
			$this->checkExistence($filePath);
	
			$this->_file = $filePath;
			return $this;

		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	set()
	 *	Sets a variable in the file
	 *	
	 *	@param string|array $varName The name of the variable
	 *	@param string|null $varVal The value of the variable
	 *	@return $this
	 */
	
	public function set($varName, $varVal = null) {

		$this->checkWritability();
		
		try {

			if (is_null($varVal)) {
				if (is_array($varName)) {
					foreach ($varName as $key => $value) {
						$this->set($key, $value);
					}
				}
				return;
			}
	
			$content = $this->getAll();
			$content[$varName] = $varVal;
			$content = json_encode($content, JSON_PRETTY_PRINT);
			file_put_contents($this->_file, $content);

		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	get()
	 *	Gets the variable value from the file
	 *	
	 *	@param string $varName The name of the variable
	 *	@return string|array
	 */
	
	public function get($varName) {

		$this->checkReadability();

		try {

			$content = $this->getAll();
			if($content[$varName]) {
				return $content[$varName];
			}

			return false;

		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	getAll()
	 *	Gets the variable value from the file
	 *	
	 *	@param string $varName The name of the variable
	 *	@return array
	 */
	
	public function getAll() {

		$this->checkReadability();
		
		try {

			$content = json_decode(file_get_contents($this->_file), true);
			return $content;

		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	_isset()
	 *	Checks if a variable is set
	 *	
	 *	@param string $varName The name of the variable
	 *	@return boolean
	 */
	
	public function _isset($varName) {

		$this->checkReadability();

		try {

			$content = $this->getAll();
			if (isset($content[$varName])) {
				return true;
			}
	
			return false;
			
		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	_unset()
	 *	Unset a variable from the file
	 *	
	 *	@param string $varName The name of the variable
	 *	@return $this
	 */
	
	public function _unset($varName) {

		$this->checkWritability();

		try {

			$content = $this->getAll();
			if ($content[$varName]) {
				unset($content[$varName]);
			}

			$content = json_encode($content, JSON_PRETTY_PRINT);
			file_put_contents($this->_file, $content);
			
		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	unsetAll()
	 *	Unset all the variables from the file
	 *	
	 *	@return $this
	 */
	
	public function unsetAll() {

		$this->checkWritability();

		try {

			file_put_contents($this->_file, '');
			return $this;

		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	create()
	 *	Create a file
	 *	
	 *	@param string $filePath Path of the file to create
	 *	@return $this
	 */

	public function create($filePath) {

		try {

			$csmUtil = new CSM_Util;
			$newFile = fopen(ROOT_PATH . $this->_storagePath . $filePath . '.json', 'w');
			fclose($newFile);

			$this->load($filePath);
			return $this;

		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

	/**
	 *	delete()
	 *	Delete a file
	 *	
	 *	@param string $filePath Path of the file to delete
	 *	@return $this
	 */

	public function delete($filePath) {

		try {

			unlink(ROOT_PATH . $this->_storagePath . $filePath . '.json');
			return true;

		} catch (Exception $e) {
			throw new Exception($e);
		}

	}

}