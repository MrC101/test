<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Load the storage file
$csmDF->load('misc');

// Fetch all the general settings
$scmSettings = $csmDF->getAll();

// Fetch default general settings
$csmSettingsDefault = json_decode(file_get_contents($csmUtil->buildPath('/defaults/misc.json')), true);;

// Generate the array
$arr = $csmSettingsDefault;
foreach ($scmSettings as $key => $value) {
	$arr[$key] = $value;
}

$arr['toggleParticles'] = $csmLanguage->get('general', 'toggleParticles');

// Assign the variables
$csmVars = array_merge($csmVars, $arr);