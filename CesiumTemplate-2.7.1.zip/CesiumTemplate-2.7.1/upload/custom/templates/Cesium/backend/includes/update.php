<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Check if update is cached
// If not, fetch it and then cache it
$cache->setCache('cesium');
if (!$cache->isCached('cesiumUpdate')) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://rms.xemstudios.com/check_update?template=cesium&version=' . $csmDF->load('info')->get('version'));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$csmUpdate = curl_exec($ch);
	$csmUpdate = json_decode($csmUpdate, true);
	curl_close($ch);
	$cache->store('cesiumUpdate', $csmUpdate, 60);
} else {
	$csmUpdate = $cache->retrieve('cesiumUpdate');
}

// Check if user has permission to cesium
// If so, generate and assign the update array
if ($user->isLoggedIn() && $user->hasPermission('cesium.main') && $csmUpdate['status'] == 'updateAvailable' && $csmUpdate['latestVersion'] == $csmDF->load('info')->get('version')) {

	$arr = array(
		'updateAvailableTitle' => $csmLanguage->get('update', 'updateAvailableTitle'),
		'updateAvailable' => $csmLanguage->get('update', 'updateAvailable'),
		'updateNow' => $csmLanguage->get('update', 'updateNow'),
		'updateLink' => URL::build($csmUtil->buildPanelURL('/update'))
	);

	// Assign the variables
	$csmVars['update'] = $arr;

}