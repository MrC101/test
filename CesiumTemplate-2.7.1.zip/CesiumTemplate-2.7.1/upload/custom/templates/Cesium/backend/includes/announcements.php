<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Load the storage file
$csmDF->load('announcements');

// Fetch all the announcements
$csmAnnouncements = $csmDF->getAll();

// Generate array from fetched announcements
$arr = array();
foreach ($csmAnnouncements as $key => $value) {

	if ($value['enabled'] && in_array(PAGE, $value['pages'])) {

		if ($user->isLoggedIn()) {

			if (in_array($user->data()->group_id, $value['groups'])) {
				if ($value['html'] == 1) {
					$value['content'] = html_entity_decode($value['content']);
				} else {
					$value['content'] = Util::urlToAnchorTag($value['content']);
				}
				$arr[$key] = str_replace(PHP_EOL, '<br>', $value);
			}

		} else {

			if (in_array('guests', $value['groups'])) {
				if ($value['html'] == 1) {
					$value['content'] = html_entity_decode($value['content']);
				} else {
					$value['content'] = Util::urlToAnchorTag($value['content']);
				}
				$arr[$key] = str_replace(PHP_EOL, '<br>', $value);
			}
			
		}
	}
}

// Assign the variables
$csmVars['announcements'] = $arr;