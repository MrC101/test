<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Get all themes
$csmDF->load('themes');
$csmThemes = $csmDF->getAll();

// Get default theme file
$csmDefaultTheme = json_decode(file_get_contents($csmUtil->buildPath('/defaults/themes/default.json')), true);

// Assign fields values
foreach ($csmDefaultTheme as $key => $value) {
	$csmThemeValues[$key] = $value;
}

// Find active theme
$csmActiveTheme = false;
foreach ($csmThemes as $key => $value) {
    if (!$csmActiveTheme && $value['enabled']) {
        $csmActiveTheme = $value;
    }
}

// Get active theme
$csmActiveTheme = $csmDF->load('themes/' . $csmActiveTheme['name'])->getAll();

// Assign fields values
foreach ($csmActiveTheme as $key => $value) {
	$csmThemeValues[$key] = $value;
}

// Load CSS file
$csmCSSFile = $csmUtil->buildTemplatePath('/assets/css/cesium.css');
$csmCSS = file_get_contents($csmCSSFile);

// Check if directory is writable
if (!is_writable($csmUtil->buildTemplatePath('/assets/css'))) {
	die('
		<h1>Cesium Template</h1>
		<p><strong>[ERROR]</strong> The directory <strong>' . $csmUtil->buildTemplatePath('/assets/css') . '</strong> is not writable.
	');
}

// Check if developer is enabled
if ($csmDF->load('misc')->get('developerMode') == 1) {

	// Generate CSS Variables
	$csmVariables = ':root {' . PHP_EOL;
	foreach ($csmThemeValues as $key => $value) {
		if ($key !== 'name' && $key !== 'author' && $key !== 'css') {
			$csmVariables .= '	--' . $key . ': ' . $value . ';' . PHP_EOL;
		}
	}
	$csmVariables .= '}' . PHP_EOL;

	// Custom CSS
	$csmCustomCSS;
	if (!empty($csmThemeValues['css'])) {
		$csmCustomCSS = PHP_EOL . '/*	CUSTOM CSS' . PHP_EOL . '	==================== */' . PHP_EOL . PHP_EOL . $csmThemeValues['css'];
	}

	// Generate CSS content
	$csmCSS = '@import url(\'' . $csmThemeValues['baseFontURL'] . '\');' . PHP_EOL . PHP_EOL . $csmVariables . PHP_EOL . $csmCSS . PHP_EOL . $csmCustomCSS;

	try {
		
		$csmCSSRawPath = $csmUtil->buildTemplatePath('/assets/css/cesium.css');
		$csmCSSFilePath = $csmUtil->buildTemplatePath('/assets/css/style.css');

		$csmCSSFile = fopen($csmCSSFilePath, 'w');

		fwrite($csmCSSFile, $csmCSS);
		fclose($csmCSSFile);

		$cache->setCache('cesium');
		if ($cache->isCached('modifiedTime')) {
			$cache->erase('modifiedTime');
		}

	} catch (Exception $e) {
		throw new Exception($e);
	}


} else {

	// Generate CSS content
	$csmCSS = '@import url(\'' . $csmThemeValues['baseFontURL'] . '\');' . $csmCSS . $csmThemeValues['css'];
	
	// Decode the variables in css
	foreach ($csmThemeValues as $key => $value) {
		$csmCSS = str_replace('var(--' . $key . ')', $value, $csmCSS);
	}
	
	// Decode the variables in css - 2nd time
	foreach ($csmThemeValues as $key => $value) {
		$csmCSS = str_replace('var(--' . $key . ')', $value, $csmCSS);
	}
	
	// Minify CSS
	$csmCSS = $csmUtil->minifyCSS($csmCSS);
	
	try {
		
		$csmStoragePath = $csmUtil->buildPath('/storage');

		$csmThemesPath = $csmStoragePath . '/themes';
		$csmThemesFiles = new DirectoryIterator($csmThemesPath);

		$latestModifiedTime = -1;
		foreach ($csmThemesFiles as $file) {
			if (!$file->isFile() || $file->isDot()) continue;
			if ($file->getMTime() > $latestModifiedTime) {
				$latestModifiedTime = $file->getMTime();
			}
		}

		if (filemtime($csmCSSFile) > $latestModifiedTime) {
			$latestModifiedTime = filemtime($csmCSSFile);
		}
		
		if (filemtime($csmStoragePath . '/themes.json') > $latestModifiedTime) {
			$latestModifiedTime = filemtime($csmStoragePath . '/themes.json');
		}

		$cache->setCache('cesium');
		if (!$cache->isCached('modifiedTime') || $cache->retrieve('modifiedTime') < $latestModifiedTime) {
			$csmFile = fopen($csmUtil->buildTemplatePath('/assets/css/style.css'), 'w');
			fwrite($csmFile, $csmCSS);
			fclose($csmFile);
			$cache->store('modifiedTime', $latestModifiedTime);
		}
	}

	catch (Exception $e) {
		throw new Exception($e);
	}

}