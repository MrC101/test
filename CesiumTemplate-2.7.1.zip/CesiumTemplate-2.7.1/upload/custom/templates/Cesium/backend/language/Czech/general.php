<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Šablona Cesium',
	'settings' => 'Obecná nastavení',
	'misc' => 'Různá nastavení',
	'permissions' => 'Oprávnění',
	'back' => 'Zpět',
	
	'dashboard' => 'Přehled',
	'basic' => 'Základní',
    'header' => 'Záhlaví',
    'navbar' => 'Navigační lišta',
    'footer' => 'Zápatí',

	'enableHeader' => 'Povolit záhlaví',
	'headerHomepage' => 'Zobrazit záhlaví pouze na domovské stránce',
	'displayMCServer' => 'Zobrazit Minecraft server',
	'displayDiscordServer' => 'Zobrazit Discord server',
	'enableLogoAnimation' => 'Povolit animaci loga',
	'headerBackground' => 'Pozadí záhlaví',
	'headerHeight' => 'Výška záhlaví',
    'logoURL' => 'URL loga',
	'logoAlt' => 'Alternativní popis',
	
	'toggleParticles' => 'Přepnout částice',
	'enableParticles' => 'Povolit částice',
	'disableParticles' => 'Zakázat částice',
	'nestedReplies' => 'Vnořené profilové odpovědi',
	'scrollToTop' => 'Povolit tlačítko skrolování nahoru',
	'developerMode' => 'Vývojářský režim',
	
	'siteTitle' => 'Název webu',
	'siteDescription' => 'Popis webu',
	'siteImage' => 'Obrázek webu',
	'siteFavicon' => 'Ikona webu',

	'navbarPosition' => 'Navbar Position',
	'navbarPositionTop' => 'Nahoře (nad záhlavím)',
	'navbarPositionBottom' => 'Dole (pod záhlavím)',
	'navbarStyle' => 'Styl navigační lišty',
	'navbarAuto' => 'Automatická',
	'navbarFull' => 'Plná (při velkém počtu položek se může rozbít)',
	'navbarSidebar' => 'Postranní panel',
	'guestDropdown' => 'Rozbalovací nabídka přihlášení/registrace',
	'panelInDropdown' => 'Přesunout odkaz na panel do uživatelské rozbalovací nabídky',
	
	'footerContent' => 'Obsah zápatí',

	'joinDiscord' => 'Připojte se na náš Discord!',
	'membersOnline' => '{x} členů online',
	'playersOnline' => '{x} hráčů online',
	
	'noNewsPosts' => 'Nejsou zde žádné příspěvky k zobrazení.',

	'new' => 'Nový',
	'import' => 'Importovat',
	'export' => 'Exportovat',
	'toggle' => 'Přepnout',
	'enable' => 'Povolit',
	'disable' => 'Zakázat',
	'edit' => 'Upravit',
	'delete' => 'Smazat',
	'cancel' => 'Zrušit',
	'submit' => 'Odeslat',
	'chooseFile' => 'Vybrat soubor',

	'success' => 'Úspěch',
	'error' => 'Chyba',
	'info' => 'Info',

	'settingsUpdated' => 'Nastavení byla úspěšně aktualizována.',
	
	'errorEdit' => 'Ujistěte se, že jsou všechna pole správně vyplněná.',
	'errorToken' => 'Neplatný token! Zkuste to prosím znovu.',

);