<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Kolotoč',

	'tittle' => 'Nadpis',
	'description' => 'Popis',
	'image' => 'URL obrázku',
	'link' => 'Odkaz',

	'settings' => 'Nastavení',
	'carouselSettings' => 'Nastavení kolotoče',
	'settingsUpdated' => 'Nastavení bylo úspěšně aktualizováno.',

	'enabled' => 'Povolit kolotoč',
	'pages' => 'Stránky kolotoče',
	'groups' => 'Skupiny kolotoče',

	'empty' => 'Kolotoč nemá žádné položky! Vytvořte nějakou kliknutím na tlačítko "Nový".',

	'new' => 'Nová položka kolotoče',
	'edit' => 'Upravit položku kolotoče',

	'successfullyCreated' => 'Položka kolotoče byla úspěšně vytvořena.',
	'successfullyDeleted' => 'Položka kolotoče byla úspěšně smazána.',
	'successfullyEdited' => 'Položka kolotoče byla úspěšně upravena.',

	'errorNew' => 'Při vytváření položky kolotoče se vyskytla chyba.',
	'errorUpdate' => 'Při aktualizaci kolotoče se vyskytla chyba.',

);