<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Cesium Template',
	'settings' => 'General Settings',
	'misc' => 'Miscellaneous Settings',
	'permissions' => 'Permissions',
	'back' => 'Back',
	
	'dashboard' => 'Dashboard',
	'basic' => 'Basic',
    'header' => 'Header',
    'navbar' => 'Navbar',
    'footer' => 'Footer',

	'enableHeader' => 'Enable Header',
	'headerHomepage' => 'Display header on only homepage',
	'displayMCServer' => 'Display Minecraft Server',
	'displayDiscordServer' => 'Display Discord Server',
	'enableLogoAnimation' => 'Enable Logo Animation',
	'headerBackground' => 'Header Background',
	'headerHeight' => 'Header Height',
    'logoURL' => 'Logo URL',
	'logoAlt' => 'Logo Alt',
	
	'toggleParticles' => 'Toggle Particles',
	'enableParticles' => 'Enable Particles',
	'disableParticles' => 'Disable Particles',
	'nestedReplies' => 'Nested Profile Post Replies',
	'scrollToTop' => 'Enable Scroll To Top Button',
	'developerMode' => 'Developer Mode',
	
	'siteTitle' => 'Site Title',
	'siteDescription' => 'Site Description',
	'siteImage' => 'Site Image',
	'siteFavicon' => 'Site Favicon',

	'navbarPosition' => 'Navbar Position',
	'navbarPositionTop' => 'Top (Above Header)',
	'navbarPositionBottom' => 'Bottom (Below Header)',
	'navbarStyle' => 'Navbar Style',
	'navbarAuto' => 'Auto',
	'navbarFull' => 'Full (Might break if you have too many items)',
	'navbarSidebar' => 'Sidebar',
	'guestDropdown' => 'Dropdown menu for login/register',
	'panelInDropdown' => 'Move panel link inside user menu dropdown',
	
	'footerContent' => 'Footer Content',

	'joinDiscord' => 'Join our Discord!',
	'membersOnline' => '{x} members online',
	'playersOnline' => '{x} players online',
	
	'noNewsPosts' => 'There are no news posts to display.',

	'new' => 'New',
	'import' => 'Import',
	'export' => 'Export',
	'toggle' => 'Toggle',
	'enable' => 'Enable',
	'disable' => 'Disable',
	'edit' => 'Edit',
	'delete' => 'Delete',
	'cancel' => 'Cancel',
	'submit' => 'Submit',
	'chooseFile' => 'Choose File',

	'success' => 'Success',
	'error' => 'Error',
	'info' => 'Info',

	'settingsUpdated' => 'Settings has been successfully updated.',
	
	'errorEdit' => 'Please ensure the fields are filled correctly.',
	'errorToken' => 'Invalid Token! Please try again.',

);