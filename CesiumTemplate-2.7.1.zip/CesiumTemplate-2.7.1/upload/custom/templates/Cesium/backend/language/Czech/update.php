<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Aktualizace',
	'checkUpdate' => 'Zkontrolovat aktualizace',

	'upToDateTitle' => 'Aktualizováno',
	'upToDate' => 'Používáte nejnovější verzi šablony Cesium.',

	'updateAvailableTitle' => 'Je dostupná aktualizace!',
	'updateAvailable' => 'Je dostupná aktualizace pro šablonu Cesium.',

	'updateNow' => 'Aktualizovat',

	'currentVersion' => 'Současná verze',
	'latestVersion' => 'Nejnovější verze',
	'changelogs' => 'Seznam změn',

	'unknownVersion' => 'Verze vaší šablony Cesium je neznámá',
	'unknownError' => 'Nastala chyba. Zkuste to prosím znovu později.',

);