<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Oznámení',
	'new' => 'Nové oznámení',
	'edit' => 'Upravit oznámení',

	'name' => 'Název oznámení',
	'content' => 'Obsah oznámení',
	'type' => 'Typ oznámení',
	'pages' => 'Lokace oznámení',
	'groups' => 'Skupiny oznámení',
	'html' => 'HTML oznámení',

	'empty' => 'Žádná oznámení! Vytvořte nějaké kliknutím na tlačítko "Nový".',

	'successfullyCreated' => 'Oznámení bylo úspěšně vytvořeno.',
	'successfullyEdited' => 'Oznámení bylo úspěšně upraveno.',
	'successfullyEnabled' => 'Oznámení bylo úspěšně povoleno.',
	'successfullyDisabled' => 'Oznámení bylo úspěšně zakázáno.',
	'successfullyDeleted' => 'Oznámení bylo úspěšně odstraněno.',

	'errorNew' => 'Ujistěte se, že název má 3 až 32 znaků, obsah alespoň 3 znaky, a že jste upřesnili typ.',
	'errorEdit' => 'Ujistěte se, že název má 3 až 32 znaků, obsah alespoň 3 znaky, a že jste upřesnili typ.',

	'typeDefault' => 'Výchozí',
	'typePrimary' => 'Primární',
	'typeSuccess' => 'Úspěch',
	'typeDanger' => 'Nebezpečí',
	'typeWarning' => 'Varování',
	'typeInfo' => 'Info',

);