<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Témata',
	'new' => 'Nové téma',
	'edit' => 'Upravit téma',
	'import' => 'Importovat téma',

	'name' => 'Název tématu',
	'author' => 'Autor tématu',

	'basic' => 'Základní nastavení',
	'colors' => 'Barvy',
	'advancedColors' => 'Pokročilé barvy',
	'advancedProperties' => 'Pokročilé vlastnosti',
	'customCSS' => 'Vlastní CSS',

	'enableBorders' => 'Povolit ohraničení',
	'enableRounded' => 'Povolit zaoblené rohy',
	'enableShadows' => 'Povolit stín boxů',

	'avatarsStyle' => 'Styl avatarů',
	'avatarsDefault' => 'Výchozí avatary',
	'avatarsRounded' => 'Zaoblené avatary',
	'avatarsCircle' => 'Kulaté avatary',

	'defaultColor' => 'Výchozí barva',
	'primaryColor' => 'Primární barva',
	'secondaryColor' => 'Sekundární barva',
	'successColor' => 'Barva úspěchu',
	'dangerColor' => 'Barva nebezpečí',
	'infoColor' => 'Barva informace',
	'warningColor' => 'Barva varování',

	'light' => 'Světlé',
	'dark' => 'Tmavé',

	'pageBackground' => 'Pozadí stránky',
	'primaryBackground' => 'Primární pozadí',
	'secondaryBackground' => 'Sekundární pozadí',

	'primaryText' => 'Primární text',
	'secondaryText' => 'Sekundární text',
	'mutedText' => 'Ztlumený text',

	'whiteColor' => 'Bílá barva',
	'gray100Color' => 'Šedá-100',
	'gray200Color' => 'Šedá-200',
	'gray300Color' => 'Šedá-300',
	'gray400Color' => 'Šedá-400',
	'gray500Color' => 'Šedá-500',
	'gray600Color' => 'Šedá-600',
	'gray700Color' => 'Šedá-700',
	'gray800Color' => 'Šedá-800',
	'gray900Color' => 'Šedá-900',
	'blackColor' => 'Černá barva',

	'fontFamily' => 'Rodina písem',
	'fontURL' => 'URL písma',
	'fontSize' => 'Velikost písma',
	'fontWeight' => 'Váha písma',
	
	'weightRegular' => 'Váha normálního písma',
	'weightMedium' => 'Váha středního písma',
	'weightBold' => 'Váha tlustého písma',
	
	'metaColor' => 'Barva Meta',
	'metaSize' => 'Velikost Meta',
	'metaWeight' => 'Váha Meta',

	'hrColor' => 'Barva Hr',
	'hrHeight' => 'Výška Hr',
	'hrSpacing' => 'Vzdálenost Hr',

	'borderSM' => 'Malé ohraničení',
	'border' => 'Střední ohraničení',
	'borderLG' => 'Velké ohraničení',

	'borderRadiusSM' => 'Malý poloměr ohraničení',
	'borderRadius' => 'Střední poloměr ohraničení',
	'borderRadiusLG' => 'Velký poloměr ohraničení',

	'boxShadowSM' => 'Krátký stín boxů',
	'boxShadow' => 'Střední stín boxů',
	'boxShadowLG' => 'Dlouhý stín boxů',

	'spacingSM' => 'Malé řádkování',
	'spacing' => 'Střední řádkování',
	'spacingLG' => 'Velké řádkování',

	'paddingSM' => 'Malé odsazení',
	'padding' => 'Střední odsazení',
	'paddingLG' => 'Velké odsazení',

	'buttonPaddingSM' => 'Malé odsazení tlačítek',
	'buttonPadding' => 'Střední odsazení tlačítek',
	'buttonPaddingLG' => 'Velké odsazení tlačítek',

	'inputPadding' => 'Odsazení vstupu',
	'inputBackground' => 'Pozadí vstupu',
	'inputBackgroundFocused' => 'Pozadí zaměřeného vstupu ',

	'cardPaddingSM' => 'Malé odsazení karet',
	'cardPadding' => 'Střední odsazení karet',
	'cardPaddingLG' => 'Velké odsazení karet',

	'css' => 'CSS',

	'successfullyCreated' => 'Téma bylo úspěšně vytvořeno.',
	'successfullyEdited' => 'Téma bylo úspěšně upraveno.',
	'successfullyEnabled' => 'Téma bylo úspěšně povoleno.',
	'successfullyDisabled' => 'Téma bylo úspěšně zakázáno.',
	'successfullyDeleted' => 'Téma bylo úspěšně odstraněno.',
	'successfullyImported' => 'Téma bylo úspěšně importováno.',

	'errorNew' => 'Ujistěte se, že název a autor mají 3 až 32 znaků.',
	'errorDeleteEnabled' => 'Nelze smazat aktivní téma.',
	'errorFileType' => 'Typ souboru musí být JSON.',
	'errorFileUpload' => 'Nahrajte soubor, potom jej odešlete.',

);