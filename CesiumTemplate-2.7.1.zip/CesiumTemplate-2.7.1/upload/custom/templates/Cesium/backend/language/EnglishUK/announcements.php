<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$language_version = '2.0.0-pr7';
  
$language = array(

	'title' => 'Announcements',
	'new' => 'New Announcement',
	'edit' => 'Edit Announcement',

	'name' => 'Announcement Name',
	'content' => 'Announcement Content',
	'type' => 'Announcement Type',
	'pages' => 'Announcement Pages',
	'groups' => 'Announcement Groups',
	'html' => 'Announcement HTML',

	'empty' => 'No announcements! Create one by clicking that "New" button.',

	'successfullyCreated' => 'Announcement has been successfully created.',
	'successfullyEdited' => 'Announcement has been successfully edited.',
	'successfullyEnabled' => 'Announcement has been successfully enabled.',
	'successfullyDisabled' => 'Announcement has been successfully disabled.',
	'successfullyDeleted' => 'Announcement has been successfully deleted.',

	'errorNew' => 'Please ensure that the name has 3-32 characters, content has atleast 3 characters, and specified a type.',
	'errorEdit' => 'Please ensure that the name has 3-32 characters, content has atleast 3 characters, and specified a type.',

	'typeDefault' => 'Default',
	'typePrimary' => 'Primary',
	'typeSuccess' => 'Success',
	'typeDanger' => 'Danger',
	'typeWarning' => 'Warning',
	'typeInfo' => 'Info',

);