<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Initialize Cesium Language
$csmLanguage = new Language(__DIR__ . '/language', LANGUAGE);

// Initialize the 'DataFile' class
require_once('classes/DataFile.php');
$csmDF = new CSM_DataFile;

// Initialize the 'Util' class
require_once('classes/Util.php');
$csmUtil = new CSM_Util;

// Require pages
require_once('utils/pages.php');

// Get the current page from url
$csmPage = (isset($_GET['page']) ? $_GET['page'] : 'general');
$csmCurrentPage = $csmPanelPages[$csmPage];

// Generate navigation
$csmNavigation = array();
foreach ($csmPanelPages as $key => $value) {
	$csmNavigation[$key] = array(
		'title' => $value['title'],
		'icon' => $value['icon'],
		'url' => $csmUtil->buildPanelURL('&page=' . $key),
		'active' => ($csmPage == $key ? 1 : 0)
	);
}

// Require legacy buttons
require_once('utils/legacyButtons.php');

// Generate breadcrumbs
$csmBreadcrumbs = array(
	'dashboard' => array(
		'name' => $csmLanguage->get('general', 'dashboard'),
		'link' => URL::build('/panel'),
	),
	'cesium' => array(
		'name' => $csmLanguage->get('general', 'title'),
		'link' => '',
	),
	$csmPage => array(
		'name' => $csmCurrentPage['title'],
		'link' => $csmUtil->buildPanelURL('&page=' . $csmPage),
	),
);

// Initialize the requested page
require_once(__DIR__ . $csmCurrentPage['page']);

// Add css files
$current_template->addCSSFiles(array(
	(defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/core/assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css' => array(),
	(defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/core/assets/plugins/switchery/switchery.min.css' => array()
));

// Add js files
$current_template->addJSFiles(array(
	(defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/core/assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js' => array(),
	(defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/core/assets/plugins/switchery/switchery.min.js' => array()
));

// Add js script
$current_template->addJSScript('
	$(\'.groupColour\').colorpicker({ format: \'hex\' });
	var elems = Array.prototype.slice.call(document.querySelectorAll(\'.js-switch\'));
	elems.forEach(function(elem) {
		var switchery = new Switchery(elem, {color: \'#23923d\', secondaryColor: \'#e56464\'});
	});
');

// Assign smarty variables
$smarty->assign(array(

	'CSM_TITLE' => $csmLanguage->get('general', 'title'),
	'CSM_PAGE_TITLE' => $csmPageTitle,

	'CSM_NAVIGATION' => $csmNavigation,
	'CSM_LEGACY_BUTTONS' => $csmLegacyButtons,
	'CSM_BREADCRUMBS' => $csmBreadcrumbs,

	'CSM_SUCCESS_TITLE' => $csmLanguage->get('general', 'success'),
	'CSM_ERROR_TITLE' => $csmLanguage->get('general', 'error'),

	'CSM_SUBMIT' => $csmLanguage->get('general', 'submit'),
	'CSM_CANCEL' => $csmLanguage->get('general', 'cancel'),
	'CSM_TOKEN' => Token::get(),

	'TEMPLATE_PATH' => $csmUtil->buildPath('/template'),
	'SETTINGS_TEMPLATE' => $csmUtil->buildPath('/template' . $csmTemplate)

));