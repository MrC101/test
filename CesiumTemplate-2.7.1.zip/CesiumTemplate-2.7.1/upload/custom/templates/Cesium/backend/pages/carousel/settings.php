<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('carousel', 'settings');

// Generate breadcrumbs
$csmBreadcrumbs['settings'] = array(
	'name' => $csmLanguage->get('carousel', 'settings'),
	'link' => '',
);

// Get settings fields
require_once('utils/fieldsSettings.php');

// Load the storage file
$csmDF->load('carousel');

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		$csmData = array();
		foreach ($csmSettingsFields as $key => $value) {
			if (isset($_POST[$value['name']])) {
				if (is_array($_POST[$value['name']])) {
					$csmData[$key] = $_POST[$value['name']];
				} else {
					$csmData[$key] = Output::getClean($_POST[$value['name']]);
				}
			}
		}

		$csmDF->set($csmData);
		$smarty->assign('CSM_SUCCESS', $csmLanguage->get('carousel', 'settingsUpdated'));

	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}

}

// Assign the field values
foreach ($csmSettingsFields as $key => $value) {
	$csmSettingsFields[$key]['value'] = $csmDF->get($key);
}

// Assign Smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmSettingsFields,
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/carousel'),
));

// Smarty template
$csmTemplate = '/carousel/settings.tpl';