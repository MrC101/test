<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmSettingsFields = array(

	'enabled' => array(
		'label' => $csmLanguage->get('carousel', 'enabled'),
		'type' => 'checkbox',
		'name' => 'csmCarouselTitle',
		'id' => 'csmCarouselTitle',
	),

	'pages' => array(
		'label' => $csmLanguage->get('carousel', 'pages'),
		'type' => 'select',
		'name' => 'csmCarouselPages',
		'id' => 'csmCarouselPages',
		'listed' => 1,
		'options' => array()
	),

	'groups' => array(
		'label' => $csmLanguage->get('carousel', 'groups'),
		'type' => 'select',
		'name' => 'csmCarouselGroups',
		'id' => 'csmCarouselGroups',
		'listed' => 1,
		'options' => array()
	),

);

$csmCarouselPages = array_filter($pages->returnPages(), function($p) {
	return $p['widgets'] == true;
});

foreach ($csmCarouselPages as $item) {
	$csmSettingsFields['pages']['options'][] = array(
		'label' => ucfirst($item['name']),
		'id' => ucfirst($item['name']),
		'value' => $item['name']
	);
}

$csmCarouselGroups = $queries->orderAll('groups', '`order`', 'ASC');

foreach($csmCarouselGroups as $item) {
	$csmSettingsFields['groups']['options'][] = array(
		'label' => $item->name,
		'id' => $item->id,
		'value' => $item->id
	);
}

$csmSettingsFields['groups']['options'][] = array(
	'label' => 'Guests',
	'id' => 'guests',
	'value' => 'guests'
);