<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('announcements', 'edit');

// Generate breadcrumbs
$csmBreadcrumbs['edit'] = array(
	'name' => $csmLanguage->get('announcements', 'edit'),
	'link' => '',
);

// Get announcement fields
require_once('utils/fields.php');

// Load storage file
$csmDF->load('announcements');

// Check if id is defined and is valid
if (!isset($_GET['id']) || !$csmDF->_isset($_GET['id'])) {
	Redirect::to($csmUtil->buildPanelURL('/announcements'));
	die();
}

// Get the announcement
$csmAnnouncement = $csmDF->get($_GET['id']);

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validation.php');
		if ($validation->passed()) {

			foreach ($csmFields as $key => $value) {
				if (isset($_POST[$value['name']])) {
					if (is_array($_POST[$value['name']])) {
						$csmAnnouncement[$key] = $_POST[$value['name']];
					} else {
						$csmAnnouncement[$key] = Output::getClean($_POST[$value['name']]);
					}
				}
			}

			$csmDF->set($_GET['id'], $csmAnnouncement);
			$smarty->assign('CSM_SUCCESS', $csmLanguage->get('announcements', 'successfullyEdited'));

		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('announcements', 'errorEdit'));
		}
		
	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}
}

// Assign the field values
foreach($csmFields as $key => $value) {
	$csmFields[$key]['value'] = $csmAnnouncement[$key];
}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmFields,
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/announcements'),
));

// Assign smarty template
$csmTemplate = '/announcements/edit.tpl';