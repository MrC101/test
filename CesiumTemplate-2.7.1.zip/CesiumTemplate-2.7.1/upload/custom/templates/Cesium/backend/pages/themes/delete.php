<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Checks if id is defined
if (isset($_GET['id'])) {

	// Load the storage file
	$csmDF->load('themes');

	// Check if theme exists
	if ($csmDF->_isset($_GET['id'])) {

		// Get the theme
		$csmTheme = $csmDF->get($_GET['id']);

		// Make sure the theme is not default
		if ($csmTheme['name'] !== 'default') {

			// Check if theme is enabled
			if ($csmTheme['enabled'] !== 1) {

				$csmDF->delete('themes/' . $csmTheme['name']);
				$csmDF->_unset($_GET['id']);
				Session::flash('CSM_SUCCESS', $csmLanguage->get('themes', 'successfullyDeleted'));

			} else {

				Session::flash('CSM_ERROR', $csmLanguage->get('themes', 'errorDeleteEnabled'));

			}

		}

	}

}

// Redirect back to index page
Redirect::to($csmUtil->buildPanelURL('/themes'));