<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Check if action is defined
if (isset($_GET['process'])) {

	$csmActions = ['new', 'edit', 'enable', 'delete', 'import', 'export'];
	if (in_array($_GET['process'], $csmActions)) {
		require_once($_GET['process'] . '.php');
	}

} else {

	// Assign page title
	$csmPageTitle = $csmLanguage->get('themes', 'title');

	// Get new theme fields
	require_once('utils/fieldsNew.php');

	// Get import theme fields
	require_once('utils/fieldsImport.php');

	// Get all themes
	$csmDF->load('themes');
	$csmThemes = $csmDF->getAll();

	// Generate themes array
	$csmThemesArr = array();
	foreach ($csmThemes as $key => $value) {
		try {
			$csmThemesArr[$key] = $csmDF->load('themes/' . $value['name'])->getAll();
			$csmThemesArr[$key]['actions'] = array(
				'enable' => array(
					'text' => $csmLanguage->get('general', 'enable'),
					'class' => 'success',
					'link' => ($value['enabled'] ? '#' : $csmUtil->buildPanelURL('/themes', 'process=enable&id=' . $key)),
				),
				'edit' => array(
					'text' => $csmLanguage->get('general', 'edit'),
					'class' => 'primary',
					'link' => $csmUtil->buildPanelURL('/themes', 'process=edit&id=' . $key),
				),
				'export' => array(
					'text' => $csmLanguage->get('general', 'export'),
					'class' => 'info',
					'link' => $csmUtil->buildPanelURL('/themes', 'process=export&id=' . $key),
				),
				'delete' => array(
					'text' => $csmLanguage->get('general', 'delete'),
					'class' => 'secondary',
					'link' => (($value['enabled'] || $value['name'] == 'default') ? '#' : $csmUtil->buildPanelURL('/themes', 'process=delete&id=' . $key)),
				),
			);
		} catch (Exception $e) {
			$csmDF->load('themes')->unset($key);
		}
	}

	// Assign session variables
	if (Session::exists('CSM_SUCCESS')) {
		$smarty->assign('CSM_SUCCESS', Session::flash('CSM_SUCCESS'));
	}

	if (Session::exists('CSM_ERROR')) {
		$smarty->assign('CSM_ERROR', Session::flash('CSM_ERROR'));
	}

	// Assign smarty variables
	$smarty->assign(array(
		'CSM_FIELDS' => $csmNewFields,
		'CSM_IMPORT_FIELDS' => $csmImportFields,
		'CSM_THEMES' => $csmThemesArr,
		'CSM_NEW_THEME' => $csmLanguage->get('themes', 'new'),
		'CSM_NEW_ACTION' => $csmUtil->buildPanelURL('/themes', 'process=new'),
		'CSM_IMPORT_THEME' => $csmLanguage->get('themes', 'import'),
		'CSM_IMPORT_ACTION' => $csmUtil->buildPanelURL('/themes', 'process=import'),
		'CSM_NEW' => $csmLanguage->get('general', 'new'),
		'CSM_IMPORT' => $csmLanguage->get('general', 'import'),
		'CSM_TOGGLE' => $csmLanguage->get('general', 'toggle'),
		'CSM_ENABLE' => $csmLanguage->get('general', 'enable'),
		'CSM_DISABLE' => $csmLanguage->get('general', 'disable'),
		'CSM_EDIT' => $csmLanguage->get('general', 'edit'),
		'CSM_DELETE' => $csmLanguage->get('general', 'delete'),
	));

	// Assign smarty template
	$csmTemplate = '/themes/index.tpl';

}