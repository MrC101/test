<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmEditFields = array(
	
	'basic' => array(
		'name' => $csmLanguage->get('themes', 'basic'),
		'id' => 'csmThemeBasicSettings',
		'fields' => array(

			'borders' => array(
				'label' => $csmLanguage->get('themes', 'enableBorders'),
				'type' => 'checkbox',
				'name' => 'csmThemeBorders',
				'id' => 'csmThemeBorders',
			),
			
			'rounded' => array(
				'label' => $csmLanguage->get('themes', 'enableRounded'),
				'type' => 'checkbox',
				'name' => 'csmThemeRounded',
				'id' => 'csmThemeRounded',
			),
			
			'shadows' => array(
				'label' => $csmLanguage->get('themes', 'enableShadows'),
				'type' => 'checkbox',
				'name' => 'csmThemeShadows',
				'id' => 'csmThemeShadows',
			),
			
			'avatars' => array(
				'label' => $csmLanguage->get('themes', 'avatarsStyle'),
				'type' => 'select',
				'name' => 'csmAvatarsStyle',
				'id' => 'csmAvatarsStyle',
				'options' => array(
					'default' => array(
						'label' => $csmLanguage->get('themes', 'avatarsDefault'),
						'id' => 'default',
						'value' => 'default',
					),
					'rounded' => array(
						'label' => $csmLanguage->get('themes', 'avatarsRounded'),
						'id' => 'rounded',
						'value' => 'rounded',
					),
					'circle' => array(
						'label' => $csmLanguage->get('themes', 'avatarsCircle'),
						'id' => 'circle',
						'value' => 'circle',
					),
				),
			),

		),
	),

	'colors' => array(
		'name' => $csmLanguage->get('themes', 'colors'),
		'id' => 'csmThemeColorsSettings',
		'fields' => array(

			'default' => array(
				'label' => $csmLanguage->get('themes', 'defaultColor'),
				'type' => 'color',
				'name' => 'csmThemeDefaultColor',
				'id' => 'csmThemeDefaultColor',
				'meta' => 'var(--default)',
			),

			'primary' => array(
				'label' => $csmLanguage->get('themes', 'primaryColor'),
				'type' => 'color',
				'name' => 'csmThemePrimaryColor',
				'id' => 'csmThemePrimaryColor',
				'meta' => 'var(--primary)',
			),

			'secondary' => array(
				'label' => $csmLanguage->get('themes', 'secondaryColor'),
				'type' => 'color',
				'name' => 'csmThemeSecondaryColor',
				'id' => 'csmThemeSecondaryColor',
				'meta' => 'var(--secondary)',
			),

			'success' => array(
				'label' => $csmLanguage->get('themes', 'successColor'),
				'type' => 'color',
				'name' => 'csmThemeSuccessColor',
				'id' => 'csmThemeSuccessColor',
				'meta' => 'var(--success)',
			),

			'danger' => array(
				'label' => $csmLanguage->get('themes', 'dangerColor'),
				'type' => 'color',
				'name' => 'csmThemeDangerColor',
				'id' => 'csmThemeDangerColor',
				'meta' => 'var(--danger)',
			),

			'info' => array(
				'label' => $csmLanguage->get('themes', 'infoColor'),
				'type' => 'color',
				'name' => 'csmThemeInfoColor',
				'id' => 'csmThemeInfoColor',
				'meta' => 'var(--info)',
			),

			'warning' => array(
				'label' => $csmLanguage->get('themes', 'warningColor'),
				'type' => 'color',
				'name' => 'csmThemeWarningColorr',
				'id' => 'csmThemeWarningColor',
				'meta' => 'var(--warning)',
			),

		),
	),
	
	'advancedColors' => array(
		'name' => $csmLanguage->get('themes', 'advancedColors'),
		'id' => 'csmThemeAdvancedSettings',
		'fields' => array(

			'pageBackground' => array(
				'label' => $csmLanguage->get('themes', 'pageBackground'),
				'type' => 'color',
				'name' => 'csmThemePageBackground',
				'id' => 'csmThemePageBackground',
				'meta' => 'var(--pageBackground)',
			),

			'primaryBackground' => array(
				'label' => $csmLanguage->get('themes', 'primaryBackground'),
				'type' => 'color',
				'name' => 'csmThemePrimaryBackground',
				'id' => 'csmThemePrimaryBackground',
				'meta' => 'var(--primaryBackground)',
			),

			'secondaryBackground' => array(
				'label' => $csmLanguage->get('themes', 'secondaryBackground'),
				'type' => 'color',
				'name' => 'csmThemeSecondaryBackground',
				'id' => 'csmThemeSecondaryBackground',
				'meta' => 'var(--secondaryBackground)',
			),

			'primaryText' => array(
				'label' => $csmLanguage->get('themes', 'primaryText'),
				'type' => 'text',
				'name' => 'csmThemePrimaryText',
				'id' => 'csmThemePrimaryText',
				'meta' => 'var(--primaryText)',
			),

			'secondaryText' => array(
				'label' => $csmLanguage->get('themes', 'secondaryText'),
				'type' => 'text',
				'name' => 'csmThemeSecondaryText',
				'id' => 'csmThemeSecondaryText',
				'meta' => 'var(--secondaryText)',
			),

			'mutedText' => array(
				'label' => $csmLanguage->get('themes', 'mutedText'),
				'type' => 'text',
				'name' => 'csmThemeMutedText',
				'id' => 'csmThemeMutedText',
				'meta' => 'var(--mutedText)',
			),

			'light' => array(
				'label' => $csmLanguage->get('themes', 'light'),
				'type' => 'text',
				'name' => 'csmThemeLight',
				'id' => 'csmThemeLight',
				'meta' => 'var(--light)',
			),

			'dark' => array(
				'label' => $csmLanguage->get('themes', 'dark'),
				'type' => 'text',
				'name' => 'csmThemeDark',
				'id' => 'csmThemeDark',
				'meta' => 'var(--dark)',
			),

			'white' => array(
				'label' => $csmLanguage->get('themes', 'whiteColor'),
				'type' => 'text',
				'name' => 'csmThemeWhite',
				'id' => 'csmThemeWhite',
				'meta' => 'var(--white)',
				'pre' => 'rgb',
			),

			'gray100' => array(
				'label' => $csmLanguage->get('themes', 'gray100Color'),
				'type' => 'text',
				'name' => 'csmThemeGray100',
				'id' => 'csmThemeGray100',
				'meta' => 'var(--gray100)',
				'pre' => 'rgb',
			),

			'gray200' => array(
				'label' => $csmLanguage->get('themes', 'gray200Color'),
				'type' => 'text',
				'name' => 'csmThemeGray200',
				'id' => 'csmThemeGray200',
				'meta' => 'var(--gray200)',
				'pre' => 'rgb',
			),

			'gray300' => array(
				'label' => $csmLanguage->get('themes', 'gray300Color'),
				'type' => 'text',
				'name' => 'csmThemeGray300',
				'id' => 'csmThemeGray300',
				'meta' => 'var(--gray300)',
				'pre' => 'rgb',
			),

			'gray400' => array(
				'label' => $csmLanguage->get('themes', 'gray400Color'),
				'type' => 'text',
				'name' => 'csmThemeGray400',
				'id' => 'csmThemeGray400',
				'meta' => 'var(--gray400)',
				'pre' => 'rgb',
			),

			'gray500' => array(
				'label' => $csmLanguage->get('themes', 'gray500Color'),
				'type' => 'text',
				'name' => 'csmThemeGray500',
				'id' => 'csmThemeGray500',
				'meta' => 'var(--gray500)',
				'pre' => 'rgb',
			),

			'gray600' => array(
				'label' => $csmLanguage->get('themes', 'gray600Color'),
				'type' => 'text',
				'name' => 'csmThemeGray600',
				'id' => 'csmThemeGray600',
				'meta' => 'var(--gray600)',
				'pre' => 'rgb',
			),

			'gray700' => array(
				'label' => $csmLanguage->get('themes', 'gray700Color'),
				'type' => 'text',
				'name' => 'csmThemeGray700',
				'id' => 'csmThemeGray700',
				'meta' => 'var(--gray700)',
				'pre' => 'rgb',
			),

			'gray800' => array(
				'label' => $csmLanguage->get('themes', 'gray800Color'),
				'type' => 'text',
				'name' => 'csmThemeGray800',
				'id' => 'csmThemeGray800',
				'meta' => 'var(--gray800)',
				'pre' => 'rgb',
			),

			'gray900' => array(
				'label' => $csmLanguage->get('themes', 'gray900Color'),
				'type' => 'text',
				'name' => 'csmThemeGray900',
				'id' => 'csmThemeGray900',
				'meta' => 'var(--gray900)',
				'pre' => 'rgb',
			),
			
			'black' => array(
				'label' => $csmLanguage->get('themes', 'blackColor'),
				'type' => 'text',
				'name' => 'csmThemeBlackColor',
				'id' => 'csmThemeBlackColor',
				'meta' => 'var(--black)',
				'pre' => 'rgb',
			),

		),
	),
	
	'advancedProperties' => array(
		'name' => $csmLanguage->get('themes', 'advancedProperties'),
		'id' => 'csmThemesAdvancedProperties',
		'fields' => array(

			'baseFontURL' => array(
				'label' => $csmLanguage->get('themes', 'fontURL'),
				'type' => 'text',
				'name' => 'csmThemeFontURL',
				'id' => 'csmThemeFontURL',
				'meta' => 'var(--baseFontURL)',
			),
			
			'baseFontFamily' => array(
				'label' => $csmLanguage->get('themes', 'fontFamily'),
				'type' => 'text',
				'name' => 'csmThemeFontFamily',
				'id' => 'csmThemeFontFamily',
				'meta' => 'var(--baseFontFamily)',
			),
			
			'baseFontSize' => array(
				'label' => $csmLanguage->get('themes', 'fontSize'),
				'type' => 'text',
				'name' => 'csmThemeFontSize',
				'id' => 'csmThemeFontSize',
				'meta' => 'var(--baseFontSize)',
			),
			
			'baseFontWeight' => array(
				'label' => $csmLanguage->get('themes', 'fontWeight'),
				'type' => 'text',
				'name' => 'csmThemeFontWeight',
				'id' => 'csmThemeFontWeight',
				'meta' => 'var(--baseFontWeight)',
			),
			
			'weightRegular' => array(
				'label' => $csmLanguage->get('themes', 'weightRegular'),
				'type' => 'text',
				'name' => 'csmThemeWeightRegular',
				'id' => 'csmThemeWeightRegular',
				'meta' => 'var(--weightRegular)',
			),
			
			'weightMedium' => array(
				'label' => $csmLanguage->get('themes', 'weightMedium'),
				'type' => 'text',
				'name' => 'csmThemeWeightMedium',
				'id' => 'csmThemeWeightMedium',
				'meta' => 'var(--weightMedium)',
			),
			
			'weightBold' => array(
				'label' => $csmLanguage->get('themes', 'weightBold'),
				'type' => 'text',
				'name' => 'csmThemeWeightBold',
				'id' => 'csmThemeWeightBold',
				'meta' => 'var(--weightBold)',
			),
			
			'metaColor' => array(
				'label' => $csmLanguage->get('themes', 'metaColor'),
				'type' => 'text',
				'name' => 'csmThemeMetaColor',
				'id' => 'csmThemeMetaColor',
				'meta' => 'var(--metaColor)',
			),
			
			'metaSize' => array(
				'label' => $csmLanguage->get('themes', 'metaSize'),
				'type' => 'text',
				'name' => 'csmThemeMetaSize',
				'id' => 'csmThemeMetaSize',
				'meta' => 'var(--metaSize)',
			),
			
			'metaWeight' => array(
				'label' => $csmLanguage->get('themes', 'metaWeight'),
				'type' => 'text',
				'name' => 'csmThemeMetaWeight',
				'id' => 'csmThemeMetaWeight',
				'meta' => 'var(--metaWeight)',
			),
			
			'hrColor' => array(
				'label' => $csmLanguage->get('themes', 'hrColor'),
				'type' => 'text',
				'name' => 'csmThemeHrColor',
				'id' => 'csmThemeHrColor',
				'meta' => 'var(--hrColor)',
			),
			
			'hrColor' => array(
				'label' => $csmLanguage->get('themes', 'hrColor'),
				'type' => 'text',
				'name' => 'csmThemeHrColor',
				'id' => 'csmThemeHrColor',
				'meta' => 'var(--hrColor)',
			),
			
			'hrHeight' => array(
				'label' => $csmLanguage->get('themes', 'hrHeight'),
				'type' => 'text',
				'name' => 'csmThemehrHeight',
				'id' => 'csmThemehrHeight',
				'meta' => 'var(--hrHeight)',
			),
			
			'hrSpacing' => array(
				'label' => $csmLanguage->get('themes', 'hrSpacing'),
				'type' => 'text',
				'name' => 'csmThemeHrSpacing',
				'id' => 'csmThemeHrSpacing',
				'meta' => 'var(--hrSpacing)',
			),
			
			'borderSM' => array(
				'label' => $csmLanguage->get('themes', 'borderSM'),
				'type' => 'text',
				'name' => 'csmThemeBorderSM',
				'id' => 'csmThemeBorderSM',
				'meta' => 'var(--borderSM)',
			),
			
			'border' => array(
				'label' => $csmLanguage->get('themes', 'border'),
				'type' => 'text',
				'name' => 'csmThemeBorder',
				'id' => 'csmThemeBorder',
				'meta' => 'var(--border)',
			),
			
			'borderLG' => array(
				'label' => $csmLanguage->get('themes', 'borderLG'),
				'type' => 'text',
				'name' => 'csmThemeBorderLG',
				'id' => 'csmThemeBorderLG',
				'meta' => 'var(--borderLG)',
			),
			
			'borderRadiusSM' => array(
				'label' => $csmLanguage->get('themes', 'borderRadiusSM'),
				'type' => 'text',
				'name' => 'csmThemeBorderRadiusSM',
				'id' => 'csmThemeBorderRadiusSM',
				'meta' => 'var(--borderRadiusSM)',
			),
			
			'borderRadius' => array(
				'label' => $csmLanguage->get('themes', 'borderRadius'),
				'type' => 'text',
				'name' => 'csmThemeBorderRadius',
				'id' => 'csmThemeBorderRadius',
				'meta' => 'var(--borderRadius)',
			),
			
			'borderRadiusLG' => array(
				'label' => $csmLanguage->get('themes', 'borderRadiusLG'),
				'type' => 'text',
				'name' => 'csmThemeBorderRadiusLG',
				'id' => 'csmThemeBorderRadiusLG',
				'meta' => 'var(--borderRadiusLG)',
			),
			
			'boxShadowSM' => array(
				'label' => $csmLanguage->get('themes', 'boxShadowSM'),
				'type' => 'text',
				'name' => 'csmThemeBoxShadowSM',
				'id' => 'csmThemeBoxShadowSM',
				'meta' => 'var(--boxShadowSM)',
			),
			
			'boxShadow' => array(
				'label' => $csmLanguage->get('themes', 'boxShadow'),
				'type' => 'text',
				'name' => 'csmThemeBoxShadow',
				'id' => 'csmThemeBoxShadow',
				'meta' => 'var(--boxShadow)',
			),
			
			'boxShadowLG' => array(
				'label' => $csmLanguage->get('themes', 'boxShadowLG'),
				'type' => 'text',
				'name' => 'csmThemeBoxShadowLG',
				'id' => 'csmThemeBoxShadowLG',
				'meta' => 'var(--boxShadowLG)',
			),
			
			'spacingSM' => array(
				'label' => $csmLanguage->get('themes', 'spacingSM'),
				'type' => 'text',
				'name' => 'csmThemeSpacingSM',
				'id' => 'csmThemeSpacingSM',
				'meta' => 'var(--spacingSM)',
			),
			
			'spacing' => array(
				'label' => $csmLanguage->get('themes', 'spacing'),
				'type' => 'text',
				'name' => 'csmThemeSpacing',
				'id' => 'csmThemeSpacing',
				'meta' => 'var(--spacing)',
			),
			
			'spacingLG' => array(
				'label' => $csmLanguage->get('themes', 'spacingLG'),
				'type' => 'text',
				'name' => 'csmThemeSpacingLG',
				'id' => 'csmThemeSpacingLG',
				'meta' => 'var(--spacingLG)',
			),
			
			'paddingSM' => array(
				'label' => $csmLanguage->get('themes', 'paddingSM'),
				'type' => 'text',
				'name' => 'csmThemePaddingSM',
				'id' => 'csmThemePaddingSM',
				'meta' => 'var(--paddingSM)',
			),
			
			'padding' => array(
				'label' => $csmLanguage->get('themes', 'padding'),
				'type' => 'text',
				'name' => 'csmThemePadding',
				'id' => 'csmThemePadding',
				'meta' => 'var(--padding)',
			),
			
			'paddingLG' => array(
				'label' => $csmLanguage->get('themes', 'paddingLG'),
				'type' => 'text',
				'name' => 'csmThemePaddingLG',
				'id' => 'csmThemePaddingLG',
				'meta' => 'var(--paddingLG)',
			),
			
			'cardPaddingSM' => array(
				'label' => $csmLanguage->get('themes', 'cardPaddingSM'),
				'type' => 'text',
				'name' => 'csmThemeCardPaddingSM',
				'id' => 'csmThemeCardPaddingSM',
				'meta' => 'var(--cardPaddingSM)',
			),
			
			'cardPadding' => array(
				'label' => $csmLanguage->get('themes', 'cardPadding'),
				'type' => 'text',
				'name' => 'csmThemeCardPadding',
				'id' => 'csmThemeCardPadding',
				'meta' => 'var(--cardPadding)',
			),
			
			'cardPaddingLG' => array(
				'label' => $csmLanguage->get('themes', 'cardPaddingLG'),
				'type' => 'text',
				'name' => 'csmThemeCardPaddingLG',
				'id' => 'csmThemeCardPaddingLG',
				'meta' => 'var(--cardPaddingLG)',
			),
			
			'buttonPaddingSM' => array(
				'label' => $csmLanguage->get('themes', 'buttonPaddingSM'),
				'type' => 'text',
				'name' => 'csmThemeButtonnPaddingSM',
				'id' => 'csmThemeButtonnPaddingSM',
				'meta' => 'var(--buttonPaddingSM)',
			),
			
			'buttonPadding' => array(
				'label' => $csmLanguage->get('themes', 'buttonPadding'),
				'type' => 'text',
				'name' => 'csmThemeButtonnPadding',
				'id' => 'csmThemeButtonnPadding',
				'meta' => 'var(--buttonPadding)',
			),
			
			'buttonPaddingLG' => array(
				'label' => $csmLanguage->get('themes', 'buttonPaddingLG'),
				'type' => 'text',
				'name' => 'csmThemeButtonnPaddingLG',
				'id' => 'csmThemeButtonnPaddingLG',
				'meta' => 'var(--buttonPaddingLG)',
			),
			
			'inputPadding' => array(
				'label' => $csmLanguage->get('themes', 'inputPadding'),
				'type' => 'text',
				'name' => 'csmThemeInputPadding',
				'id' => 'csmThemeInputPadding',
				'meta' => 'var(--inputPadding)',
			),
			
			'inputBackground' => array(
				'label' => $csmLanguage->get('themes', 'inputBackground'),
				'type' => 'text',
				'name' => 'csmThemeInputBackground',
				'id' => 'csmThemeInputBackground',
				'meta' => 'var(--inputBackground)',
			),
			
			'inputBackgroundFocused' => array(
				'label' => $csmLanguage->get('themes', 'inputBackgroundFocused'),
				'type' => 'text',
				'name' => 'csmThemeInputBackgroundFocused',
				'id' => 'csmThemeInputBackgroundFocused',
				'meta' => 'var(--inputBackgroundFocused)',
			),

		),

	),
	
	'customCSS' => array(
		'name' => $csmLanguage->get('themes', 'customCSS'),
		'id' => 'csmThemesCustomCSS',
		'fields' => array(
			
			'css' => array(
				'label' => $csmLanguage->get('themes', 'css'),
				'type' => 'textarea',
				'name' => 'csmThemeCSS',
				'id' => 'csmThemeCSS',
			),

		),

	),

);