<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Checks if the id is defined
if (isset($_GET['id'])) {

	// Load the storage file
	$csmDF->load('carousel');
	
	// Get all carousel items
	$csmCarousel = $csmDF->getAll();

	// Check if carousel item exists
	if ($csmCarousel['items'][$_GET['id']]) {
		unset($csmCarousel['items'][$_GET['id']]);
		$csmDF->set($csmCarousel);
		Session::flash('CSM_SUCCESS', $csmLanguage->get('carousel', 'successfullyDeleted'));
	}

}

// Redirect back to index page
Redirect::to($csmUtil->buildPanelURL('/carousel'));
die();