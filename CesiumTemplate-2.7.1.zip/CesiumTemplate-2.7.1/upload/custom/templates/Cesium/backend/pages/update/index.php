<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('update', 'title');

// Fetch update data
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://rms.xemstudios.com/check_update?template=cesium&version=' . $csmDF->load('info')->get('version'));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$csmUpdate = curl_exec($ch);
$csmUpdate = json_decode($csmUpdate, true);
curl_close($ch);

// Generate status
if ($csmUpdate['status'] == 'updateAvailable') {

	$array = array();

	$array['CSM_UPDATE_AVAILABLE_TITLE'] = $csmLanguage->get('update', 'updateAvailableTitle');
	$array['CSM_UPDATE_AVAILABLE'] = $csmLanguage->get('update', 'updateAvailable');

	$array['CSM_UPDATE_NOW'] = $csmLanguage->get('update', 'updateNow');
	$array['CSM_UPDATE_LINK'] = $csmUpdate['updateLink'];

	$array['CSM_CURRENT_VERSION_TITLE'] = $csmLanguage->get('update', 'currentVersion');
	$array['CSM_CURRENT_VERSION'] = $csmUpdate['currentVersion'];

	$array['CSM_LATEST_VERSION_TITLE'] = $csmLanguage->get('update', 'latestVersion');
	$array['CSM_LATEST_VERSION'] = $csmUpdate['latestVersion'];

	$array['CSM_CHANGELOGS_TITLE'] = $csmLanguage->get('update', 'changelogs');
	$array['CSM_CHANGELOGS'] = array();
	foreach ($csmUpdate['updates'] as $key => $val) {
		foreach ($val['changelogs'] as $sKey => $sVal) {
			$array['CSM_CHANGELOGS'][] = array(
				'version' => $key,
				'content' => $sVal,
			);
		}
	}

	$smarty->assign($array);

} else if ($csmUpdate['status'] == 'upToDate') {

	$array = array();

	$array['CSM_UP_TO_DATE_TITLE'] = $csmLanguage->get('update', 'upToDateTitle');
	$array['CSM_UP_TO_DATE'] = $csmLanguage->get('update', 'upToDate');

	$array['CSM_CURRENT_VERSION_TITLE'] = $csmLanguage->get('update', 'currentVersion');
	$array['CSM_CURRENT_VERSION'] = $csmUpdate['currentVersion'];

	$array['CSM_LATEST_VERSION_TITLE'] = $csmLanguage->get('update', 'latestVersion');
	$array['CSM_LATEST_VERSION'] = $csmUpdate['latestVersion'];

	$smarty->assign($array);

} else if ($csmUpdate['status'] == 'unknownVersion') {

	$array = array();

	$array['CSM_ERROR'] = $csmLanguage->get('update', 'unknownVersion');

	$array['CSM_CURRENT_VERSION_TITLE'] = $csmLanguage->get('update', 'currentVersion');
	$array['CSM_CURRENT_VERSION'] = $csmUpdate['currentVersion'];

	$smarty->assign($array);

} else {

	$smarty->assign('CSM_ERROR', $csmLanguage->get('update', 'unknownError'));

}

// Assign session variables
if (Session::exists('CSM_SUCCESS')) {
	$smarty->assign('CSM_SUCCESS', Session::flash('CSM_SUCCESS'));
}

if (Session::exists('CSM_ERROR')) {
	$smarty->assign('CSM_ERROR', Session::flash('CSM_ERROR'));
}

// Assign Smarty variables
$smarty->assign(array(
	'CSM_CHECK_UPDATE' => $csmLanguage->get('update', 'checkUpdate'),
	'CSM_INFO_TITLE' => $csmLanguage->get('general', 'info'),
));

// Assign smarty template
$csmTemplate = '/update/index.tpl';