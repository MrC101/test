<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('general', 'misc');

// Get fields
require_once('utils/fields.php');

// Load the storage file
$csmDF->load('misc');

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validation.php');
		if ($validation->passed()) {

			$csmData = array();
			foreach ($csmFields as $key => $value) {
				if (isset($_POST[$value['name']])) {
					$csmData[$key] = $_POST[$value['name']];
				}
			}

			$csmDF->set($csmData);
			$smarty->assign('CSM_SUCCESS', $csmLanguage->get('general', 'settingsUpdated'));
			
		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorEdit'));
		}
		
	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}

}

// Assign fields values
foreach ($csmFields as $key => $value) {
	$csmFields[$key]['value'] = $csmDF->get($key);
}

// Assign session variables
if (Session::exists('CSM_SUCCESS')) {
	$smarty->assign('CSM_SUCCESS', Session::flash('CSM_SUCCESS'));
}

if (Session::exists('CSM_ERROR')) {
	$smarty->assign('CSM_ERROR', Session::flash('CSM_ERROR'));
}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmFields,
));

// Assign smarty template
$csmTemplate = '/misc/index.tpl';