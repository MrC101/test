<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmNewFields = array(

	'name' => array(
		'label' => $csmLanguage->get('themes', 'name'),
		'type' => 'text',
		'name' => 'csmThemeName',
		'id' => 'csmThemeName',
	),

	'author' => array(
		'label' => $csmLanguage->get('themes', 'author'),
		'type' => 'text',
		'name' => 'csmThemeAuthor',
		'id' => 'csmThemeAuthor',
	),

);
