<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle =  $csmLanguage->get('themes', 'new');

// Generate breadcrumbs
$csmBreadcrumbs['new'] = array(
	'name' => $csmLanguage->get('themes', 'new'),
	'link' => '',
);

// Get new theme fields
require_once('utils/fieldsNew.php');

// Load the storage file
$csmDF->load('themes');

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validationNew.php');
		if ($validation->passed()) {

			// Get default theme file
			$csmDefaultTheme = json_decode(file_get_contents($csmUtil->buildPath('/defaults/themes/default.json')), true);

			// Assign fields values
			foreach ($csmDefaultTheme as $key => $value) {
				$csmThemeValues[$key] = $value;
			}

			// Assign new field values
			foreach ($csmNewFields as $key => $value) {
				$csmDefaultTheme[$key] = $_POST[$value['name']];
			}

			$csmNewTheme = array(
				'name' => $csmUtil->sanitizeString($_POST['csmThemeName']),
				'enabled' => 0
			);

			$csmThemesDirectory = $csmUtil->buildPath('/storage/themes/');
			$csmFilePath = $csmThemesDirectory . $csmNewTheme['name'] . '.json';

			if (file_exists($csmFilePath)) {
				$i = 0;
				$csmFileNameOrigin = $csmNewTheme['name'];
				while (file_exists($csmFilePath)) {
					$i++;
					$csmNewTheme['name'] = $csmFileNameOrigin . '_' . $i;
					$csmFilePath = $csmThemesDirectory . $csmNewTheme['name'] . '.json';
				}
			}

			$csmDF->create('themes/' . $csmNewTheme['name'])->set($csmDefaultTheme);
			$csmDF->load('themes')->set((int)max(array_keys($csmDF->getAll())) + 1, $csmNewTheme);

			Session::flash('CSM_SUCCESS', $csmLanguage->get('themes', 'successfullyCreated'));
			Redirect::to($csmUtil->buildPanelURL('/themes'));

		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('themes', 'errorNew'));
		}

	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}
}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmNewFields,
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/themes'),
));

// Assign smarty template
$csmTemplate = '/themes/new.tpl';