<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Check if action is set
if (isset($_GET['process'])) {

	$csmActions = ['new', 'edit', 'delete', 'settings'];
	if (in_array($_GET['process'], $csmActions)) {
		require_once($_GET['process'] . '.php');
	}

} else {

	// Assign page title
	$csmPageTitle = $csmLanguage->get('carousel', 'title');

	// Get carousel fields
	require_once('utils/fields.php');

	// Load the storage file
	$csmDF->load('carousel');

	// Get all the carousel
	$csmCarousel = $csmDF->getAll();

	// Generate carousel array
	$csmCarouselArr = array();
	foreach($csmCarousel['items'] as $key => $value) {
		$csmCarouselArr[$key] = $csmCarousel['items'][$key];
		$csmCarouselArr[$key]['actions'] = array(
			'edit' => array(
				'text' => $csmLanguage->get('general', 'edit'),
				'class' => 'primary',
				'link' => $csmUtil->buildPanelURL('/carousel', 'process=edit&id=' . $key),
			),
			'delete' => array(
				'text' => $csmLanguage->get('general', 'delete'),
				'class' => 'secondary',
				'link' => $csmUtil->buildPanelURL('/carousel', 'process=delete&id=' . $key),
			),
		);
	}

	// Assign session variables
	if (Session::exists('CSM_SUCCESS')) {
		$smarty->assign('CSM_SUCCESS', Session::flash('CSM_SUCCESS'));
	}

	if (Session::exists('CSM_ERROR')) {
		$smarty->assign('CSM_ERROR', Session::flash('CSM_ERROR'));
	}

	// Assign smarty variables
	$smarty->assign(array(
		'CSM_FIELDS' => $csmFields,
		'CSM_CAROUSEL' => $csmCarouselArr,
		'CSM_EMPTY_CAROUSEL' => $csmLanguage->get('carousel', 'empty'),
		'CSM_SETTINGS' => $csmLanguage->get('carousel', 'settings'),
		'CSM_SETTINGS_ACTION' => $csmUtil->buildPanelURL('/carousel', 'process=settings'),
		'CSM_NEW_CAROUSEL' => $csmLanguage->get('carousel', 'new'),
		'CSM_NEW_ACTION' => $csmUtil->buildPanelURL('/carousel', 'process=new'),
		'CSM_NEW' => $csmLanguage->get('general', 'new'),
		'CSM_DELETE' => $csmLanguage->get('general', 'delete'),
	));

	// Assign smarty template
	$csmTemplate = '/carousel/index.tpl';

}