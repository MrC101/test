<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$validate = new Validate();

$validation = $validate->check($_POST, array(

    // ...
	
));