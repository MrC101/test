<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Assign page title
$csmPageTitle = $csmLanguage->get('carousel', 'new');

// Generate breadcrumbs
$csmBreadcrumbs['new'] = array(
	'name' => $csmLanguage->get('carousel', 'new'),
	'link' => '',
);

// Get announcement fields
require_once('utils/fields.php');

// Loadthe storage file
$csmDF->load('carousel');

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validation.php');
		if ($validation->passed()) {

			$csmData = array();
			foreach ($csmFields as $key => $value) {
				if (isset($_POST[$value['name']])) {
					if (is_array($_POST[$value['name']])) {
						$csmData[$key] = $_POST[$value['name']];
					} else {
						$csmData[$key] = Output::getClean($_POST[$value['name']]);
					}
				}
			}

			$csmCarousel = $csmDF->getAll();
			$csmCarousel['items'][(int)max(array_keys($csmCarousel['items'])) + 1] = $csmData;

			$csmDF->set($csmCarousel);

			Session::flash('CSM_SUCCESS', $csmLanguage->get('carousel', 'successfullyCreated'));
			Redirect::to($csmUtil->buildPanelURL('/carousel'));

		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('carousel', 'errorNew'));
		}

	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}

}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmFields,
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/carousel'),
));

// Assign smarty template
$csmTemplate = '/carousel/new.tpl';