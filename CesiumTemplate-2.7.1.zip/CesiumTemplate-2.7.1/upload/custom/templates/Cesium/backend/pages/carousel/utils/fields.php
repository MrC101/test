<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmFields = array(

	'title' => array(
		'label' => $csmLanguage->get('carousel', 'tittle'),
		'type' => 'text',
		'name' => 'csmCarouselTitle',
		'id' => 'csmCarouselTitle',
	),

	'description' => array(
		'label' => $csmLanguage->get('carousel', 'description'),
		'type' => 'text',
		'name' => 'csmCarouselDescription',
		'id' => 'csmCarouselDescription',
	),

	'image' => array(
		'label' => $csmLanguage->get('carousel', 'image'),
		'type' => 'text',
		'name' => 'csmCarouselImage',
		'id' => 'csmCarouselImage',
	),

	'link' => array(
		'label' => $csmLanguage->get('carousel', 'link'),
		'type' => 'text',
		'name' => 'csmCarouselLink',
		'id' => 'csmCarouselLink',
	),

);