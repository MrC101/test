<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

// Checks if id is defined
if (isset($_GET['id'])) {
	$csmDF->load('themes');
	if (!$csmDF->_isset($_GET['id'])) {
		Redirect::to($csmUtil->buildPanelURL('/themes'));
	} else {
		$csmTheme = $csmDF->get($_GET['id']);
	}
}

// Initialize the page
$csmPageTitle = $csmLanguage->get('themes', 'edit');

// Generate breadcrumbs
$csmBreadcrumbs['edit'] = array(
	'name' => $csmLanguage->get('themes', 'edit'),
	'link' => '',
);

// Get theme edit fields
require_once('utils/fieldsEdit.php');

// Get theme file
$csmDF->load('themes/' . $csmTheme['name']);

// Check if method is post
if (Input::exists()) {

	// Validate token
	if (Token::check(Input::get('token'))) {

		// Validate input
		require_once('utils/validationEdit.php');
		if ($validation->passed()) {

			// Check if action is defined and is valid
			if (isset($_POST['action']) && array_key_exists($_POST['action'], $csmEditFields)) {

				$csmData = array();
				foreach ($csmEditFields[$_POST['action']]['fields'] as $key => $value) {
					$csmData[$key] = $_POST[$value['name']];
				}
	
				$csmDF->set($csmData);
				$smarty->assign('CSM_SUCCESS', $csmLanguage->get('themes', 'successfullyEdited'));

			}
			
		} else {
			$smarty->assign('CSM_ERROR', $csmLanguage->get('themes', 'errorEdit'));
		}
		
	} else {
		$smarty->assign('CSM_ERROR', $csmLanguage->get('general', 'errorToken'));
	}
	
}

// Get default theme file
$csmDefaultTheme = json_decode(file_get_contents($csmUtil->buildPath('/defaults/themes/default.json')), true);

// Assign fields values
foreach ($csmEditFields as $key => $value) {
	foreach ($value['fields'] as $sKey => $sValue) {
		$csmEditFields[$key]['fields'][$sKey]['value'] = $csmDefaultTheme[$sKey];
	}
}

// Get theme file
$csmDF->load('themes/' . $csmTheme['name']);

// Assign fields values
foreach ($csmEditFields as $key => $value) {
	foreach ($value['fields'] as $sKey => $sValue) {
		if ($csmDF->_isset($sKey)) {
			$csmEditFields[$key]['fields'][$sKey]['value'] = $csmDF->get($sKey);
		}
	}
}

// Assign active tab pane
if (isset($_POST['action']) && array_key_exists($_POST['action'], $csmEditFields)) {
	$csmEditFields[$_POST['action']]['active'] = 1;
} else {
	foreach ($csmEditFields as $key => $value) {
		$csmEditFields[$key]['active'] = 1;
		break;
	}
}

// Assign session variables
if (Session::exists('CSM_SUCCESS')) {
	$smarty->assign('CSM_SUCCESS', Session::flash('CSM_SUCCESS'));
}

if (Session::exists('CSM_ERROR')) {
	$smarty->assign('CSM_ERROR', Session::flash('CSM_ERROR'));
}

// Assign smarty variables
$smarty->assign(array(
	'CSM_FIELDS' => $csmEditFields,
	'CSM_IMPORT_THEME' => $csmLanguage->get('themes', 'import'),
	'CSM_IMPORT_ACTION' => $csmUtil->buildPanelURL('/themes', 'process=import'),
	'CSM_CANCEL_LINK' => $csmUtil->buildPanelURL('/themes'),
));

// Assign smarty template
$csmTemplate = '/themes/edit.tpl';