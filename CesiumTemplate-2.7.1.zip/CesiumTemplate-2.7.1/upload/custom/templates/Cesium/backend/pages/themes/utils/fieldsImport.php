<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmImportFields = array(

	'theme' => array(
		'label' => $csmLanguage->get('general', 'chooseFile'),
		'type' => 'file',
		'name' => 'csmThemeFile',
		'id' => 'csmThemeFile',
	),

);