<?php

/**
 *	CESIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

$csmFields = array(

	'particles' => array(
		'label' => $csmLanguage->get('general', 'enableParticles'),
		'type' => 'checkbox',
		'name' => 'csmMiscParticles',
		'id' => 'csmMiscParticles',
	),

	'nestedReplies' => array(
		'label' => $csmLanguage->get('general', 'nestedReplies'),
		'type' => 'checkbox',
		'name' => 'csmMiscNestedReplies',
		'id' => 'csmMiscNestedReplies',
		'meta' => 'Show post replies without clicking replies button on profile page'
	),

	'scrollToTop' => array(
		'label' => $csmLanguage->get('general', 'scrollToTop'),
		'type' => 'checkbox',
		'name' => 'csmMiscScrollToTop',
		'id' => 'csmMiscScrollToTop'
	),

	'developerMode' => array(
		'label' => $csmLanguage->get('general', 'developerMode'),
		'type' => 'checkbox',
		'name' => 'csmMiscDeveloperMode',
		'id' => 'csmMiscDeveloperMode',
	),

);